# ==============================================================================
# LIBRARIES & DATA LOADING
# ==============================================================================

# Load the tidyverse core packages (ggplot2, dplyr, tidyr, readr, etc.)
library(tidyverse)

# Read the raw COVID cases dataset from an RDS file
covid_cases <- read_rds("data/covid_cases.rds")

# ==============================================================================
# DATA CLEANING & RESHAPING
# ==============================================================================

covid_cases <- covid_cases |>
  # Reshape data from wide to long format so each row represents one date-country observation
  pivot_longer(
    -date,                                 # Keep 'date' as a static column
    names_to = "country",                  # Store country identifiers in a new column
    names_pattern = "cases_(.+)",          # Extract country code from column names like "cases_usa"
    values_to = "cases"                    # Store case counts in a new 'cases' column
  ) |>
  # Extract the week number from the date column
  mutate(week = week(date)) |>
  # Remove negative case values (data errors) and filter for the first 12 weeks (week < 13)
  filter(cases > -1, week < 3 + 10)

# Define the number of top countries to display separately in plots/tables
top_n <- 5 

# Identify the top 5 countries by total case count
top_countries <- covid_cases |>
  group_by(country) |>                     # Group observations by country
  summarise(total_cases = sum(cases)) |>   # Calculate total cases per country
  slice_max(total_cases, n = top_n) |>     # Select the top N countries with highest cases
  pull(country)                            # Extract country names as a character vector

# ==============================================================================
# PREPARING DATA FOR AREA CHART
# ==============================================================================

plot_data <- covid_cases |>
  # Group by country to calculate overall totals for lumping
  group_by(country) |>
  mutate(total_cases = sum(cases)) |>
  ungroup() |>
  # Keep top N countries as individual factors; group all other countries into "Others"
  mutate(
    country = fct_lump_n(country, n = top_n, w = total_cases, other_level = "Others") |>
      fct_relevel("Others", after = Inf)   # Move "Others" to the last position in factor levels
  ) |>
  # Aggregate case totals by date and lumped country factor
  group_by(date, country) |>
  summarise(total_cases = sum(cases)) |>
  # Calculate daily percentage share of total cases per country group
  mutate(
    pct_cases = total_cases / sum(total_cases) * 100
  ) |>
  drop_na()                                 # Remove rows containing missing values

# ==============================================================================
# REGION MAPPING & AGGREGATIONS
# ==============================================================================

# Read region lookup dataset
region <- read_rds("data/country_region.rds")

# Merge region information into the main COVID cases dataset using ISO 3-letter country codes
covid_cases <- covid_cases |> 
  left_join(region, by = join_by(country == alpha_3))

# Aggregation check 1: Total cases grouped by main region
tmp1 <- covid_cases |> 
  group_by(region) |> 
  summarise(total_cases = sum(cases), .groups = "drop")

# Aggregation check 2: Total cases grouped by sub-region
tmp2 <- covid_cases |> 
  group_by(sub_region) |> 
  summarise(total_cases = sum(cases), .groups = "drop")

# ==============================================================================
# DATA VISUALIZATION (100% STACKED AREA CHART)
# ==============================================================================

plot_data |>
  ggplot(aes(x = date, y = pct_cases, fill = country)) +
  geom_area() +                           # Render area chart showing proportions over time
  scale_y_continuous(
    "Percent of total cases",             # Y-axis label
    breaks = seq(0, 100, 10),             # Axis ticks at intervals of 10%
    labels = paste0(seq(0, 100, 10), "%") # Format labels with percentage signs
  ) +
  scale_x_date(
    "Date",                               # X-axis label
    date_breaks = "1 week",               # Major tick mark every week
    date_labels = "W%W",                  # Format date as week number (e.g., W01)
    minor_breaks = NULL                   # Turn off minor gridlines
  ) +
  scale_fill_discrete(
    "Country",                            # Legend title
    labels = c(                           # Map country codes to readable names for the legend
      "chn" = "China",
      "deu" = "Germany",
      "esp" = "Spain",
      "ita" = "Italy",
      "usa" = "USA"
    )
  ) +
  ggtitle("Percentage of COVID case counts per country for the first 10 weeks of 2020")

# ==============================================================================
# SUMMARY TABLE CREATION (gt PACKAGE)
# ==============================================================================

# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================

# Custom function to calculate weighted standard deviation:
# Formula: sqrt( sum(w * (x - weighted_mean)^2) / sum(w) )
weighted_sd <- function(x, w) {
  # Filter out pairs where either x or weight w is NA, or weight is non-positive
  valid <- !is.na(x) & !is.na(w) & w > 0
  x <- x[valid]
  w <- w[valid]
  
  # Return NA if no valid data points remain or total weight is zero
  if (length(x) == 0 || sum(w) == 0) return(NA_real_)
  
  # Calculate the weighted mean: sum(w * x) / sum(w)
  w_mean <- sum(w * x) / sum(w)
  
  # Calculate weighted population variance: sum(w * (x - w_mean)^2) / sum(w)
  w_var <- sum(w * (x - w_mean)^2) / sum(w)
  
  # Return standard deviation (square root of variance)
  return(sqrt(w_var))
}

# ==============================================================================
# WEIGHTED REGION & SUB-REGION SUMMARIES
# ==============================================================================

# 1. Calculate weighted summary statistics for top-level Regions (Parent Rows)
region_summary <- covid_cases |> 
  group_by(region) |> 
  summarise(
    label = first(region),                                   # Display label for the region
    total_cases = sum(cases, na.rm = TRUE),                  # Total cumulative cases
    mean_week = weighted.mean(week, w = cases, na.rm = TRUE),# Case-weighted average week
    sd_week = weighted_sd(week, w = cases),                  # Case-weighted standard deviation
    is_subregion = FALSE,                                    # Flag indicating a parent row
    .groups = "drop"
  )

# 2. Calculate weighted summary statistics for Sub-regions (Child Rows)
subregion_summary <- covid_cases |> 
  group_by(region, sub_region) |> 
  summarise(
    label = first(sub_region),                               # Display label for the sub-region
    total_cases = sum(cases, na.rm = TRUE),                  # Total cumulative cases
    mean_week = weighted.mean(week, w = cases, na.rm = TRUE),# Case-weighted average week
    sd_week = weighted_sd(week, w = cases),                  # Case-weighted standard deviation
    is_subregion = TRUE,                                     # Flag indicating a child row
    .groups = "drop"
  )

# ==============================================================================
# DATA COMBINATION & FORMATTING
# ==============================================================================

# 3. Combine parent and child rows, order hierarchically, and select export columns
summary_table <- bind_rows(region_summary, subregion_summary) |> 
  arrange(region, is_subregion, label) |>  # Order by region name, placing parents before children
  mutate(
    # Add HTML non-breaking spaces (&nbsp;) to indent sub-region names
    `Region / Sub-Region` = if_else(is_subregion, paste0("&nbsp;&nbsp;&nbsp;&nbsp;", label), label),
    
    # Format the weighted mean and SD into a combined display string "Mean (SD)"
    `Mean Week (SD)` = sprintf("%.2f (%.2f)", mean_week, sd_week)
  ) |> 
  # Retain only the columns required for final presentation + helper flag
  select(
    `Region / Sub-Region`,
    `Total Cases` = total_cases,
    `Mean Week (SD)`,
    is_subregion
  )

# ==============================================================================
# TABLE RENDERING (gt PACKAGE)
# ==============================================================================

# 4. Generate formatted HTML table using gt
summary_table |> 
  gt() |> 
  cols_hide(columns = is_subregion) |>              # Hide the helper flag column from the final output
  fmt_markdown(columns = `Region / Sub-Region`) |>  # Process HTML entities so indentation spaces display correctly
  fmt_number(columns = `Total Cases`, decimals = 0) |> # Format total cases with thousands separators and no decimals
  tab_style(
    style = cell_text(weight = "bold"),             # Apply bold styling
    locations = cells_body(
      rows = is_subregion == FALSE                  # Bold parent region rows only
    )
  )